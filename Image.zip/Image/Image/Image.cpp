// Image.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include "pch.h"
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace std;
using namespace cv;

#define PI 3.1415

const int row = 640;
const int col = 480;
const int datarow = 3;
const int datacol = 5;


//void Interpolation(Mat finalimage, Mat image, Mat d_x, Mat d_y)
//{
//		double min, max;
//		minMaxLoc(image, &min, &max);
//		for (int y = 0; y < row; y++)
//		{
//			for (int x = 0; x < col; x++)
//			{
//				int i = y + (x * row);
//				{
//					int newx = x - d_x.data[i * 3 + 0];
//					int newy = y - d_y.data[i * 3 + 0];
//					if (newx >= 0 && newy >= 0)
//					{
//						int newi = newy + (newx * row);
//						finalimage.data[i * 3 + 0] = image.data[newi * 3 + 0];
//						finalimage.data[i * 3 + 1] = image.data[newi * 3 + 1];
//						finalimage.data[i * 3 + 2] = image.data[newi * 3 + 2];
//					}
//				}
//			}
//		}
//}
void Normalization(Mat d_x, Mat d_y)
{
	double magnitude[row][col];
	for (int y = 0; y < row; y++)
	{
		for (int x = 0; x < col; x++)
		{
			int i = y + (x * row);
			{
				magnitude[y][x] = sqrt(pow(d_x.data[i * 3 + 0], 2) + pow(d_y.data[i * 3 + 0], 2));
				d_x.data[i * 3 + 0] = d_x.data[i * 3 + 0] / magnitude[y][x];
				d_x.data[i * 3 + 1] = d_x.data[i * 3 + 1]  / magnitude[y][x];
				d_x.data[i * 3 + 2] = d_x.data[i * 3 + 2]  / magnitude[y][x];
				d_y.data[i * 3 + 0] = d_y.data[i * 3 + 0]  / magnitude[y][x];
				d_y.data[i * 3 + 1] = d_y.data[i * 3 + 1]  / magnitude[y][x];
				d_y.data[i * 3 + 2] = d_y.data[i * 3 + 2]  / magnitude[y][x];
			}
		}
	}
}


void ImageGeneration(Mat finalimage, Mat image1, Mat image2, int scale, int input1scale, int input2scale)
{
	for (int y = 0; y < row; y++)
	{
		for (int x = 0; x < col; x++)
		{
			int i = y + (x * row);
			{
				finalimage.data[i * 3 + 0] = image1.data[i * 3 * input1scale + 0] * image2.data[i * 3 * input2scale + 0]  / scale;
				finalimage.data[i * 3 + 1] = image1.data[i * 3 * input1scale + 1] * image2.data[i * 3 * input2scale + 1]  / scale;
				finalimage.data[i * 3 + 2] = image1.data[i * 3 * input1scale + 2] * image2.data[i * 3 * input2scale + 2]  / scale;
			}
		}
	}
}
//void Convert(Mat finalimage, Mat image, double scale)
//{
//	for (int y = 0; y < row; y++)
//	{
//		for (int x = 0; x < col; x++)
//		{
//			int i = y + (x * row);
//			{
//				finalimage.data[i * 3 + 0] = scale * image.data[i * 3 + 0];
//				finalimage.data[i * 3 + 1] = scale * image.data[i * 3 + 1];
//				finalimage.data[i * 3 + 2] = scale * image.data[i * 3 + 2];
//			}
//		}
//	}
//}
//void OpticalFlow(Mat input, double(*data)[datacol])
//{
//	int scale = 1;
//	imshow("input", input);
//	double val1 = 0;
//	Mat d_x = imread("C:\\Users\\tapadhird\\source\\repos\\Image\\fjords.jpg", CV_LOAD_IMAGE_COLOR);
//	Mat d_y = imread("C:\\Users\\tapadhird\\source\\repos\\Image\\fjords.jpg", CV_LOAD_IMAGE_COLOR);
//	for (int y = 0; y < row; y++)
//	{
//		for (int x = 0; x < col; x++)
//		{
//			int i = y + (x * row);
//			{
//				for (int k = 0; k < 1; k++)
//				{
//					val1 = abs(data[k][1] - x);
//					d_x.data[i * 3 + 0] = val1 ;
//					d_x.data[i * 3 + 1] = val1 ;
//					d_x.data[i * 3 + 2] = val1 ;
//					d_x.data[i * 3 + 0] = d_x.data[i * 3 + 0] * input.data[i * 3 + 0] / scale;
//					d_x.data[i * 3 + 1] = d_x.data[i * 3 + 1] * input.data[i * 3 + 1] / scale;
//					d_x.data[i * 3 + 2] = d_x.data[i * 3 + 2] * input.data[i * 3 + 2] / scale;
//				}
//			}
//		}
//	}
//
//	for (int y = 0; y < row; y++)
//	{
//		for (int x = 0; x < col; x++)
//		{
//			int i = y + (x * row);
//			{
//				for (int k = 0; k < 1; k++)
//				{
//					val1 = abs(data[k][2] - y);
//					d_y.data[i * 3 + 0] = val1 ;
//					d_y.data[i * 3 + 1] = val1 ;
//					d_y.data[i * 3 + 2] = val1 ;
//					d_y.data[i * 3 + 0] = d_y.data[i * 3 + 0] * input.data[i * 3 + 0] / scale;
//					d_y.data[i * 3 + 1] = d_y.data[i * 3 + 1] * input.data[i * 3 + 1] / scale;
//					d_y.data[i * 3 + 2] = d_y.data[i * 3 + 2] * input.data[i * 3 + 2] / scale;
//				}
//			}
//		}
//	}
//
//	//Normalization(d_x, d_y);
//
//	Mat newd_x = imread("C:\\Users\\tapadhird\\source\\repos\\Image\\fjords.jpg", CV_LOAD_IMAGE_COLOR);
//	Mat newd_y = imread("C:\\Users\\tapadhird\\source\\repos\\Image\\fjords.jpg", CV_LOAD_IMAGE_COLOR);
//	Mat finalimage = imread("C:\\Users\\tapadhird\\source\\repos\\Image\\fjords.jpg", CV_LOAD_IMAGE_COLOR);
//	Mat finalimage2 = finalimage.clone();
//
//
//
//	double min, max;
//	minMaxLoc(d_x, &min, &max);
//	cout << "min: " << min << ", max: " << max  << endl;
//
//	minMaxLoc(d_y, &min, &max);
//	cout << "min: " << min << ", max: " << max << endl;
//
//
//
//	//subtract(cv::Scalar::all(255), d_x, d_x); //Flips black and white portions of an image
//	//subtract(cv::Scalar::all(255), d_y, d_y); //Flips black and white portions of an image
//
//	imshow("d_x", d_x);
//	imshow("d_y", d_y);
//
//
//
//
//
//
//
//	/*minMaxLoc(d_y, &min, &max);
//	cout << "min: " << min << ", max: " << max << endl;*/
//
//
//	//imshow("prefinal", finalimage);
//	/*imshow("finalinputpre", finalimage);
//	minMaxLoc(d_x, &min, &max);
//	cout << "min: " << min << ", max: " << max << endl;
//	minMaxLoc(d_y, &min, &max);
//	cout << "min: " << min << ", max: " << max << endl;*/
//
//	Interpolation(finalimage2, finalimage, d_x, d_y);
//	//Map location of pixels and then interpolate
//
//
//
//	imshow("postfinal", finalimage2);
//	
//	minMaxLoc(finalimage, &min, &max);
//	cout << "min: " << min << ", max: " << max << endl;
//	//ImageGeneration(d_x, d_x, input, 255, 1, 1);
//	/*double min, max;
//	minMaxLoc(d_x, &min, &max);
//	cout << "min: " << min << ", max: " << max  << endl;*/
//
//	//ImageGeneration(d_y, d_y, input, 255, 1, 1);
//	//Interpolation(finalimage2, finalimage2, d_x, d_y);
//	
//	//imshow("final255", finalimage2);
//	//Shift(input, d_x, d_y);
//}



void MaskGenerator(double (*data)[datacol], double (*imagearray)[col]){
	double a, b, c, d, e = 0.0;
	for (int x = 0; x < row; x++)
	{
		for (int y = 0; y < col; y++)
		{
			double value = 0.0;
			for (int i = 0; i < datarow; i++)
			{
				a = pow((x - data[i][1]), 2);
				b = pow((y - data[i][2]), 2);
				c = a + b;
				d = 2 * pow(data[i][3], 2)*pow(data[i][4], 2);
				e = c / d;
				e = exp(-e);
				value = value + (data[i][0] *e*255);
				//value = value + (data[i][0] * (0.5)*PI*(exp(-(pow((x - data[i][1]), 2) + pow((y - data[i][2]), 2) / 2 * pow(data[i][3], 2)*pow(data[i][4], 2)))));
			}
			imagearray[x][y] = value;  
		}
	}
}
void SingleMaskGenerator(double(*data)[datacol], double(*imagearray)[col])
{
	double a, b, c, d, e = 0.0;
	for (int x = 0; x < row; x++)
	{
		for (int y = 0; y < col; y++)
		{
			double value = 0.0;
			for (int i = 0; i < 1; i++)
			{
				a = pow((x - data[i][1]), 2);
				b = pow((y - data[i][2]), 2);
				c = a + b;
				d = 2 * pow(data[i][3], 2)*pow(data[i][4], 2);
				e = c / d;
				e = exp(-e);
				value = data[i][0] * e;
			}
			imagearray[x][y] = value;
		}
	}
}

void InverseMaskGenerator(double (*imagearray)[col], Mat theMask){
	//cout << "mask data@ " << 200 << "," << 260 << "= " << (int) theMask.data[(270 + 270 * theMask.rows)*3];
	for (int x = 0; x < col; x++)
	{
		for (int y = 0; y < row; y++)
		{
			int i = y + (x * row);

			imagearray[y][x] =127.0/ (theMask.data[i*3+0]); // Mapping data from 0-255 to -0.5 to 0.5
		}
	}
	//cout << "\nimagearray " << 200 << "," << 260<< "= " << imagearray[270][270];
}
void MaskToImage(Mat image, double(*imagearray)[col], double scale, int imagescale)
{
	for (int y = 0; y < row; y++)
	{
		for (int x = 0; x < col; x++)
		{
			int i = y + (x * row);
			{
				image.data[i * 3 * imagescale + 0] = scale * imagearray[y][x];
				image.data[i * 3 * imagescale + 1] = scale * imagearray[y][x];
				image.data[i * 3 * imagescale + 2] = scale * imagearray[y][x];
			}
		}
	}
}


void GetData( ifstream & file, double (*data)[datacol], int ID)
{
	
	int counter = 0;
	if (file.is_open())
	{
		while (!file.eof())
		{
			if (counter == 0)
			{
				file >> ID;
				counter++;
			}
			else
			{
				for (int i = 0; i < datarow; i++)
				{
					for (int j = 0; j < datacol; j++)
					{
						file >> data[i][j];
					}
				}
			}
		}
		file.close();
	}
	else
	{
		cout << "File Could Not Be Opened" << endl;
	}
}



void Squish(Mat image, Mat finalimage, Mat mask, double(*data)[datacol],double scale)
{
	//imshow("mask", mask);
	//Mat image =  imread("C:\\Users\\tapadhird\\source\\repos\\Image\\Board.png", CV_LOAD_IMAGE_COLOR);
	//Mat finalimage = image.clone();
	//imshow("mask", mask);
	//imshow("prefinalimage", finalimage);

	int width = col;
	int height = row;


	for (int x = 0; x < col; x++)
	{
		for (int y = 0; y < row;y++)
		{
			int i = y + (x * row);
			{

				int dx = (x - data[0][1]) + (x - data[1][1]) + (x - data[2][1]);
				int dy = (y - data[0][2]) + (y - data[1][2]) + (y - data[2][2]);

				double theta = atan2(dy, dx);
				double dist = sqrt(pow(dy,2) + pow(dx,2));

				double value = mask.data[i*3+0] * scale;

				int finalx1 = ceil(x + dist *  value * cos(theta));
				int finaly1 = ceil(y + dist *  value* sin(theta));
				int finalx2 = floor(x + dist * value * cos(theta));
				int finaly2 = floor(y + dist * value* sin(theta));


				if (finalx1 <= 0 || finalx1 >= width)
				{
					finalx1 = x;
				}
				if (finalx2 <= 0 || finalx2 >= width)
				{
					finalx2 = x;
				}
				if (finaly1 <= 0 || finaly1 >= height)
				{
					finaly1 = y;
				}
				if (finaly2 <= 0 || finaly2 >= height)
				{
					finaly2 = y;
				}
				int i1 = finaly1 + (finalx1 * row);
				int i2 = finaly1 + (finalx2 *row);
				int i3 = finaly2 + (finalx1 * row);
				int i4 = finaly2 + (finalx2 * row);

				int val = (image.data[i1 * 3 + 0] + image.data[i2 * 3 + 0] + image.data[i3 * 3 + 0] + image.data[i4 * 3 + 0])/4;
				finalimage.data[i * 3 + 0] = val;
				val = (image.data[i1 * 3 + 1] + image.data[i2 * 3 + 1] + image.data[i3 * 3 + 1] + image.data[i4 * 3 + 1]) / 4;
				finalimage.data[i * 3 + 1] = val;
				val = (image.data[i1 * 3 + 2] + image.data[i2 * 3 + 2] + image.data[i3 * 3 + 2] + image.data[i4 * 3 + 2]) / 4;
				finalimage.data[i * 3 + 2] = val;

			}
		}		
	}

}


void Crosshair(Mat image, Mat crosshair, int location[2])
{
	int lowx = location[0] - (crosshair.cols / 2);
	int highx = location[0] + (crosshair.cols / 2);
	int lowy = location[1] - (crosshair.rows / 2);
	int highy = location[1] + (crosshair.rows / 2);

	int crossx = 0;
	int crossy = 0;
	bool inside = false;

	for (int y = 0; y < row; y++)
	{
		for (int x = 0; x < col; x++)
		{
			int i = y + (x * row);
			int crossi = (y - lowy - 1) + ((x - lowx - 1) * crosshair.rows);
			{
				if (x > lowx && x <= highx && y > lowy && y <= highy)
				{
					image.data[i * 3 + 0] = image.data[i * 3 + 0] * crosshair.data[crossi * 3 + 0]/255;
					image.data[i * 3 + 1] = image.data[i * 3 + 1] * crosshair.data[crossi * 3 + 1]/255;
					image.data[i * 3 + 2] = image.data[i * 3 + 2] * crosshair.data[crossi * 3 + 2]/255;
				}
				else
				{
					inside = false;
					image.data[i * 3 + 0] = image.data[i * 3 + 0];
					image.data[i * 3 + 1] = image.data[i * 3 + 1];
					image.data[i * 3 + 2] = image.data[i * 3 + 2];
				}
			}
		}
	}
}

void CircleGeneration(Mat image, Mat mask,Mat fimage)
{
	Mat test = fimage.clone();
	int prei = 0;
	int preprei = 0;
	for (int y = 0; y < row; y++)
	{
		for (int x = 0; x < col; x++)
		{
			int i = y + (x * row);
			{
				if (mask.data[prei * 3 + 0] == 0 && mask.data[i * 3 + 0] != 0 || mask.data[prei * 3 + 0] != 0 && mask.data[i * 3 + 0] == 0)
				{
					image.data[i * 3 + 0] = 0;
					image.data[i * 3 + 1] = 0;
					image.data[i * 3 + 2] = 255;
					image.data[prei * 3 + 0] = 0;
					image.data[prei * 3 + 1] = 0;
					image.data[prei * 3 + 2] = 255;
					image.data[preprei * 3 + 0] = 0;
					image.data[preprei * 3 + 1] = 0;
					image.data[preprei * 3 + 2] = 255;
				}
			}
			preprei = prei;
			prei = i;
		}
	}
	for (int y = 0; y < row; y++)
	{
		for (int x = 0; x < col; x++)
		{
			int i = y + (x * row);
			{
				test.data[i * 3 + 0] = fimage.data[i * 3 + 0] * image.data[i * 3 + 0] / 255;
				test.data[i * 3 + 1] = fimage.data[i * 3 + 1] * image.data[i * 3 + 1] / 255;
				test.data[i * 3 + 2] = fimage.data[i * 3 + 2] * image.data[i * 3 + 2] / 255;
			}
		}
	}

	imshow("Test Image", test);
}
int main()
{
	int ID = 0;
	double data[datarow][datacol];
	double imagearray[row][col];
	ifstream file("C:\\Users\\tapadhird\\Desktop\\Masks\\Mask1.txt");
	GetData(file, data, ID);
	Mat mask = imread("C:\\Users\\tapadhird\\source\\repos\\Image\\RightMask.jpg", CV_LOAD_IMAGE_COLOR);
	Mat input = imread("C:\\Users\\tapadhird\\source\\repos\\Image\\fjords.jpg", CV_LOAD_IMAGE_COLOR);
	Mat circle = mask.clone();

	//
	//imshow("Input", input);
	Mat affected;
	mask.copyTo(affected);
	Mat invMask(input.rows,input.cols, CV_32FC3);

	if (!mask.data)
	{
		cout << "Could not open or find the image" << endl;
		return -1;
	}

	Mat crosshair_img = imread("C:\\Users\\tapadhird\\source\\repos\\Image\\Crosshair.jpg", CV_LOAD_IMAGE_COLOR);


	//MaskGenerator(data, imagearray);
	SingleMaskGenerator(data, imagearray);
	//MaskToImage(mask, imagearray,1,1);
	MaskToImage(mask, imagearray, 255, 1);


	Mat finalinput = input.clone();
	imshow("prefinalimage", finalinput);
	Squish(input,finalinput, mask,data,0.002);
	imshow("postfinalimage", finalinput);

	/*int location[2];
	cout << "Enter location of crosshair" << endl;
	for (int i = 0; i < 2; i++)
	{
		cin >> location[i];
	}
	Crosshair(finalinput, crosshair_img, location)*/;

	//CircleGeneration(circle, mask,finalinput);

	imshow("mask", mask);
	imshow("Circle", circle);

	//imshow("postfinalimage", finalinput);

	imwrite("C:\\Users\\tapadhird\\source\\repos\\Image\\GeneratedCrossHair.jpg", finalinput);
	//subtract(cv::Scalar::all(255), mask, mask); //Flips black and white portions of an image
	imwrite("C:\\Users\\tapadhird\\source\\repos\\Image\\GeneratedMask.jpg", mask);

	MaskToImage(mask, imagearray, 1, 1);

	subtract(cv::Scalar::all(255), mask, mask); //Flips black and white portions of an image
	//show("rotatemask", mask);

	
	//imshow("mask", mask);
	InverseMaskGenerator(imagearray,mask);
	MaskToImage(invMask, imagearray, 127,4);

	//imshow("invMask", invMask);




	ImageGeneration(affected, input, mask, 255,1,1);
	
	//imshow("affected", affected);

	Mat corrected;
	affected.copyTo(corrected);


	ImageGeneration(corrected, affected, invMask, 63, 1, 4);


	//imshow("corrected", corrected);
	imwrite("C:\\Users\\tapadhird\\source\\repos\\Image\\InverseMask.jpg", invMask);

	waitKey(0);
}


	